﻿namespace Harjoitustyö_Roope_ja_Jenna
{
    partial class frmHenkilotietoLomake
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblTyösuhdeTiedot = new System.Windows.Forms.Label();
            this.lblOsoiteTiedot = new System.Windows.Forms.Label();
            this.lblHenkiloTiedot = new System.Windows.Forms.Label();
            this.lblYksikkö = new System.Windows.Forms.Label();
            this.lblNimike = new System.Windows.Forms.Label();
            this.lblPaattyminen = new System.Windows.Forms.Label();
            this.lblAlkaminen = new System.Windows.Forms.Label();
            this.lblPostiPaikka = new System.Windows.Forms.Label();
            this.lblPostiNro = new System.Windows.Forms.Label();
            this.lblOsoite = new System.Windows.Forms.Label();
            this.lblHetu = new System.Windows.Forms.Label();
            this.lblKutsumanimi = new System.Windows.Forms.Label();
            this.lblSukunimi = new System.Windows.Forms.Label();
            this.lblEtunimet = new System.Windows.Forms.Label();
            this.cbYksikko = new System.Windows.Forms.ComboBox();
            this.cbNimike = new System.Windows.Forms.ComboBox();
            this.dtpPaattyminen = new System.Windows.Forms.DateTimePicker();
            this.dtpAlkaminen = new System.Windows.Forms.DateTimePicker();
            this.tbPostiPaikka = new System.Windows.Forms.TextBox();
            this.tbPostiNro = new System.Windows.Forms.TextBox();
            this.tbOsoite = new System.Windows.Forms.TextBox();
            this.tbHetu = new System.Windows.Forms.TextBox();
            this.tbKutsumanimi = new System.Windows.Forms.TextBox();
            this.tbSukunimi = new System.Windows.Forms.TextBox();
            this.tbEtunimet = new System.Windows.Forms.TextBox();
            this.btnVieTiedot = new System.Windows.Forms.Button();
            this.lbTiedot = new System.Windows.Forms.ListBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.tiedostoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.järjestäToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsAÖ = new System.Windows.Forms.ToolStripMenuItem();
            this.kutsumanimiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sukunimiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nimikeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsÖA = new System.Windows.Forms.ToolStripMenuItem();
            this.kutsumanimiToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.sukunimiToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.nimikeToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.btnMuokkaa = new System.Windows.Forms.Button();
            this.btnPoista = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel1.Controls.Add(this.lblTyösuhdeTiedot);
            this.panel1.Controls.Add(this.lblOsoiteTiedot);
            this.panel1.Controls.Add(this.lblHenkiloTiedot);
            this.panel1.Controls.Add(this.lblYksikkö);
            this.panel1.Controls.Add(this.lblNimike);
            this.panel1.Controls.Add(this.lblPaattyminen);
            this.panel1.Controls.Add(this.lblAlkaminen);
            this.panel1.Controls.Add(this.lblPostiPaikka);
            this.panel1.Controls.Add(this.lblPostiNro);
            this.panel1.Controls.Add(this.lblOsoite);
            this.panel1.Controls.Add(this.lblHetu);
            this.panel1.Controls.Add(this.lblKutsumanimi);
            this.panel1.Controls.Add(this.lblSukunimi);
            this.panel1.Controls.Add(this.lblEtunimet);
            this.panel1.Controls.Add(this.cbYksikko);
            this.panel1.Controls.Add(this.cbNimike);
            this.panel1.Controls.Add(this.dtpPaattyminen);
            this.panel1.Controls.Add(this.dtpAlkaminen);
            this.panel1.Controls.Add(this.tbPostiPaikka);
            this.panel1.Controls.Add(this.tbPostiNro);
            this.panel1.Controls.Add(this.tbOsoite);
            this.panel1.Controls.Add(this.tbHetu);
            this.panel1.Controls.Add(this.tbKutsumanimi);
            this.panel1.Controls.Add(this.tbSukunimi);
            this.panel1.Controls.Add(this.tbEtunimet);
            this.panel1.Location = new System.Drawing.Point(43, 34);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(462, 458);
            this.panel1.TabIndex = 0;
            // 
            // lblTyösuhdeTiedot
            // 
            this.lblTyösuhdeTiedot.AutoSize = true;
            this.lblTyösuhdeTiedot.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTyösuhdeTiedot.Location = new System.Drawing.Point(19, 297);
            this.lblTyösuhdeTiedot.Name = "lblTyösuhdeTiedot";
            this.lblTyösuhdeTiedot.Size = new System.Drawing.Size(134, 22);
            this.lblTyösuhdeTiedot.TabIndex = 24;
            this.lblTyösuhdeTiedot.Text = "Työsuhdetiedot";
            // 
            // lblOsoiteTiedot
            // 
            this.lblOsoiteTiedot.AutoSize = true;
            this.lblOsoiteTiedot.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOsoiteTiedot.Location = new System.Drawing.Point(19, 173);
            this.lblOsoiteTiedot.Name = "lblOsoiteTiedot";
            this.lblOsoiteTiedot.Size = new System.Drawing.Size(106, 22);
            this.lblOsoiteTiedot.TabIndex = 23;
            this.lblOsoiteTiedot.Text = "Osoitetiedot";
            // 
            // lblHenkiloTiedot
            // 
            this.lblHenkiloTiedot.AutoSize = true;
            this.lblHenkiloTiedot.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHenkiloTiedot.Location = new System.Drawing.Point(19, 14);
            this.lblHenkiloTiedot.Name = "lblHenkiloTiedot";
            this.lblHenkiloTiedot.Size = new System.Drawing.Size(114, 22);
            this.lblHenkiloTiedot.TabIndex = 22;
            this.lblHenkiloTiedot.Text = "Henkilötiedot";
            // 
            // lblYksikkö
            // 
            this.lblYksikkö.AutoSize = true;
            this.lblYksikkö.Location = new System.Drawing.Point(30, 409);
            this.lblYksikkö.Name = "lblYksikkö";
            this.lblYksikkö.Size = new System.Drawing.Size(45, 13);
            this.lblYksikkö.TabIndex = 21;
            this.lblYksikkö.Text = "Yksikkö";
            // 
            // lblNimike
            // 
            this.lblNimike.AutoSize = true;
            this.lblNimike.Location = new System.Drawing.Point(30, 381);
            this.lblNimike.Name = "lblNimike";
            this.lblNimike.Size = new System.Drawing.Size(39, 13);
            this.lblNimike.TabIndex = 20;
            this.lblNimike.Text = "Nimike";
            // 
            // lblPaattyminen
            // 
            this.lblPaattyminen.AutoSize = true;
            this.lblPaattyminen.Location = new System.Drawing.Point(30, 357);
            this.lblPaattyminen.Name = "lblPaattyminen";
            this.lblPaattyminen.Size = new System.Drawing.Size(123, 13);
            this.lblPaattyminen.TabIndex = 19;
            this.lblPaattyminen.Text = "Työsuhteen päättyminen";
            // 
            // lblAlkaminen
            // 
            this.lblAlkaminen.AutoSize = true;
            this.lblAlkaminen.Location = new System.Drawing.Point(30, 331);
            this.lblAlkaminen.Name = "lblAlkaminen";
            this.lblAlkaminen.Size = new System.Drawing.Size(114, 13);
            this.lblAlkaminen.TabIndex = 18;
            this.lblAlkaminen.Text = "Työsuhteen alkaminen";
            // 
            // lblPostiPaikka
            // 
            this.lblPostiPaikka.AutoSize = true;
            this.lblPostiPaikka.Location = new System.Drawing.Point(31, 264);
            this.lblPostiPaikka.Name = "lblPostiPaikka";
            this.lblPostiPaikka.Size = new System.Drawing.Size(83, 13);
            this.lblPostiPaikka.TabIndex = 17;
            this.lblPostiPaikka.Text = "Postitoimipaikka";
            // 
            // lblPostiNro
            // 
            this.lblPostiNro.AutoSize = true;
            this.lblPostiNro.Location = new System.Drawing.Point(31, 235);
            this.lblPostiNro.Name = "lblPostiNro";
            this.lblPostiNro.Size = new System.Drawing.Size(65, 13);
            this.lblPostiNro.TabIndex = 16;
            this.lblPostiNro.Text = "Postinumero";
            // 
            // lblOsoite
            // 
            this.lblOsoite.AutoSize = true;
            this.lblOsoite.Location = new System.Drawing.Point(30, 207);
            this.lblOsoite.Name = "lblOsoite";
            this.lblOsoite.Size = new System.Drawing.Size(57, 13);
            this.lblOsoite.TabIndex = 15;
            this.lblOsoite.Text = "Katuosoite";
            // 
            // lblHetu
            // 
            this.lblHetu.AutoSize = true;
            this.lblHetu.Location = new System.Drawing.Point(30, 144);
            this.lblHetu.Name = "lblHetu";
            this.lblHetu.Size = new System.Drawing.Size(114, 13);
            this.lblHetu.TabIndex = 14;
            this.lblHetu.Text = "Henkilötunnus (HETU)";
            // 
            // lblKutsumanimi
            // 
            this.lblKutsumanimi.AutoSize = true;
            this.lblKutsumanimi.Location = new System.Drawing.Point(30, 111);
            this.lblKutsumanimi.Name = "lblKutsumanimi";
            this.lblKutsumanimi.Size = new System.Drawing.Size(66, 13);
            this.lblKutsumanimi.TabIndex = 13;
            this.lblKutsumanimi.Text = "Kutsumanimi";
            // 
            // lblSukunimi
            // 
            this.lblSukunimi.AutoSize = true;
            this.lblSukunimi.Location = new System.Drawing.Point(30, 79);
            this.lblSukunimi.Name = "lblSukunimi";
            this.lblSukunimi.Size = new System.Drawing.Size(50, 13);
            this.lblSukunimi.TabIndex = 12;
            this.lblSukunimi.Text = "Sukunimi";
            // 
            // lblEtunimet
            // 
            this.lblEtunimet.AutoSize = true;
            this.lblEtunimet.Location = new System.Drawing.Point(30, 49);
            this.lblEtunimet.Name = "lblEtunimet";
            this.lblEtunimet.Size = new System.Drawing.Size(48, 13);
            this.lblEtunimet.TabIndex = 11;
            this.lblEtunimet.Text = "Etunimet";
            // 
            // cbYksikko
            // 
            this.cbYksikko.FormattingEnabled = true;
            this.cbYksikko.Items.AddRange(new object[] {
            "Johtoyksikkö",
            "Kehitysyksikkö"});
            this.cbYksikko.Location = new System.Drawing.Point(180, 406);
            this.cbYksikko.Name = "cbYksikko";
            this.cbYksikko.Size = new System.Drawing.Size(243, 21);
            this.cbYksikko.TabIndex = 10;
            // 
            // cbNimike
            // 
            this.cbNimike.FormattingEnabled = true;
            this.cbNimike.Items.AddRange(new object[] {
            "Johtaja",
            "Esihenkilö",
            "Ohjelmistokehittäjä",
            "Työntekijä"});
            this.cbNimike.Location = new System.Drawing.Point(180, 378);
            this.cbNimike.Name = "cbNimike";
            this.cbNimike.Size = new System.Drawing.Size(243, 21);
            this.cbNimike.TabIndex = 9;
            // 
            // dtpPaattyminen
            // 
            this.dtpPaattyminen.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpPaattyminen.Location = new System.Drawing.Point(180, 351);
            this.dtpPaattyminen.Name = "dtpPaattyminen";
            this.dtpPaattyminen.Size = new System.Drawing.Size(243, 20);
            this.dtpPaattyminen.TabIndex = 8;
            // 
            // dtpAlkaminen
            // 
            this.dtpAlkaminen.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpAlkaminen.Location = new System.Drawing.Point(180, 324);
            this.dtpAlkaminen.Name = "dtpAlkaminen";
            this.dtpAlkaminen.Size = new System.Drawing.Size(243, 20);
            this.dtpAlkaminen.TabIndex = 7;
            // 
            // tbPostiPaikka
            // 
            this.tbPostiPaikka.Location = new System.Drawing.Point(181, 261);
            this.tbPostiPaikka.Name = "tbPostiPaikka";
            this.tbPostiPaikka.Size = new System.Drawing.Size(243, 20);
            this.tbPostiPaikka.TabIndex = 6;
            // 
            // tbPostiNro
            // 
            this.tbPostiNro.Location = new System.Drawing.Point(181, 232);
            this.tbPostiNro.Name = "tbPostiNro";
            this.tbPostiNro.Size = new System.Drawing.Size(243, 20);
            this.tbPostiNro.TabIndex = 5;
            this.tbPostiNro.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbPostiNro_KeyPress);
            this.tbPostiNro.Leave += new System.EventHandler(this.tbPostiNro_Leave);
            // 
            // tbOsoite
            // 
            this.tbOsoite.Location = new System.Drawing.Point(180, 204);
            this.tbOsoite.Name = "tbOsoite";
            this.tbOsoite.Size = new System.Drawing.Size(243, 20);
            this.tbOsoite.TabIndex = 4;
            // 
            // tbHetu
            // 
            this.tbHetu.Location = new System.Drawing.Point(180, 141);
            this.tbHetu.Name = "tbHetu";
            this.tbHetu.Size = new System.Drawing.Size(243, 20);
            this.tbHetu.TabIndex = 3;
            this.tbHetu.Leave += new System.EventHandler(this.tbHetu_Leave);
            // 
            // tbKutsumanimi
            // 
            this.tbKutsumanimi.Location = new System.Drawing.Point(180, 108);
            this.tbKutsumanimi.Name = "tbKutsumanimi";
            this.tbKutsumanimi.Size = new System.Drawing.Size(243, 20);
            this.tbKutsumanimi.TabIndex = 2;
            // 
            // tbSukunimi
            // 
            this.tbSukunimi.Location = new System.Drawing.Point(180, 76);
            this.tbSukunimi.Name = "tbSukunimi";
            this.tbSukunimi.Size = new System.Drawing.Size(243, 20);
            this.tbSukunimi.TabIndex = 1;
            // 
            // tbEtunimet
            // 
            this.tbEtunimet.Location = new System.Drawing.Point(180, 46);
            this.tbEtunimet.Name = "tbEtunimet";
            this.tbEtunimet.Size = new System.Drawing.Size(243, 20);
            this.tbEtunimet.TabIndex = 0;
            // 
            // btnVieTiedot
            // 
            this.btnVieTiedot.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVieTiedot.Location = new System.Drawing.Point(136, 511);
            this.btnVieTiedot.Name = "btnVieTiedot";
            this.btnVieTiedot.Size = new System.Drawing.Size(265, 51);
            this.btnVieTiedot.TabIndex = 1;
            this.btnVieTiedot.Text = "Vie Tiedot";
            this.btnVieTiedot.UseVisualStyleBackColor = true;
            this.btnVieTiedot.Click += new System.EventHandler(this.btnVieTiedot_Click);
            // 
            // lbTiedot
            // 
            this.lbTiedot.BackColor = System.Drawing.SystemColors.ControlLight;
            this.lbTiedot.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTiedot.FormattingEnabled = true;
            this.lbTiedot.HorizontalScrollbar = true;
            this.lbTiedot.ItemHeight = 16;
            this.lbTiedot.Location = new System.Drawing.Point(533, 34);
            this.lbTiedot.Name = "lbTiedot";
            this.lbTiedot.Size = new System.Drawing.Size(774, 452);
            this.lbTiedot.TabIndex = 2;
            this.lbTiedot.DoubleClick += new System.EventHandler(this.lbTiedot_DoubleClick);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tiedostoToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1335, 24);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // tiedostoToolStripMenuItem
            // 
            this.tiedostoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.järjestäToolStripMenuItem});
            this.tiedostoToolStripMenuItem.Name = "tiedostoToolStripMenuItem";
            this.tiedostoToolStripMenuItem.Size = new System.Drawing.Size(64, 20);
            this.tiedostoToolStripMenuItem.Text = "Tiedosto";
            // 
            // järjestäToolStripMenuItem
            // 
            this.järjestäToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsAÖ,
            this.tsÖA});
            this.järjestäToolStripMenuItem.Name = "järjestäToolStripMenuItem";
            this.järjestäToolStripMenuItem.Size = new System.Drawing.Size(112, 22);
            this.järjestäToolStripMenuItem.Text = "Järjestä";
            // 
            // tsAÖ
            // 
            this.tsAÖ.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.kutsumanimiToolStripMenuItem,
            this.sukunimiToolStripMenuItem,
            this.nimikeToolStripMenuItem});
            this.tsAÖ.Name = "tsAÖ";
            this.tsAÖ.Size = new System.Drawing.Size(96, 22);
            this.tsAÖ.Text = "A-Ö";
            this.tsAÖ.Click += new System.EventHandler(this.tsAO_Click);
            // 
            // kutsumanimiToolStripMenuItem
            // 
            this.kutsumanimiToolStripMenuItem.Name = "kutsumanimiToolStripMenuItem";
            this.kutsumanimiToolStripMenuItem.Size = new System.Drawing.Size(145, 22);
            this.kutsumanimiToolStripMenuItem.Text = "Kutsumanimi";
            this.kutsumanimiToolStripMenuItem.Click += new System.EventHandler(this.tsAO_Click);
            // 
            // sukunimiToolStripMenuItem
            // 
            this.sukunimiToolStripMenuItem.Name = "sukunimiToolStripMenuItem";
            this.sukunimiToolStripMenuItem.Size = new System.Drawing.Size(145, 22);
            this.sukunimiToolStripMenuItem.Text = "Sukunimi";
            this.sukunimiToolStripMenuItem.Click += new System.EventHandler(this.tsAO_Click);
            // 
            // nimikeToolStripMenuItem
            // 
            this.nimikeToolStripMenuItem.Name = "nimikeToolStripMenuItem";
            this.nimikeToolStripMenuItem.Size = new System.Drawing.Size(145, 22);
            this.nimikeToolStripMenuItem.Text = "Nimike";
            this.nimikeToolStripMenuItem.Click += new System.EventHandler(this.tsAO_Click);
            // 
            // tsÖA
            // 
            this.tsÖA.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.kutsumanimiToolStripMenuItem1,
            this.sukunimiToolStripMenuItem1,
            this.nimikeToolStripMenuItem1});
            this.tsÖA.Name = "tsÖA";
            this.tsÖA.Size = new System.Drawing.Size(96, 22);
            this.tsÖA.Text = "Ö-A";
            this.tsÖA.Click += new System.EventHandler(this.tsOA_Click);
            // 
            // kutsumanimiToolStripMenuItem1
            // 
            this.kutsumanimiToolStripMenuItem1.Name = "kutsumanimiToolStripMenuItem1";
            this.kutsumanimiToolStripMenuItem1.Size = new System.Drawing.Size(145, 22);
            this.kutsumanimiToolStripMenuItem1.Text = "Kutsumanimi";
            this.kutsumanimiToolStripMenuItem1.Click += new System.EventHandler(this.tsOA_Click);
            // 
            // sukunimiToolStripMenuItem1
            // 
            this.sukunimiToolStripMenuItem1.Name = "sukunimiToolStripMenuItem1";
            this.sukunimiToolStripMenuItem1.Size = new System.Drawing.Size(145, 22);
            this.sukunimiToolStripMenuItem1.Text = "Sukunimi";
            this.sukunimiToolStripMenuItem1.Click += new System.EventHandler(this.tsOA_Click);
            // 
            // nimikeToolStripMenuItem1
            // 
            this.nimikeToolStripMenuItem1.Name = "nimikeToolStripMenuItem1";
            this.nimikeToolStripMenuItem1.Size = new System.Drawing.Size(145, 22);
            this.nimikeToolStripMenuItem1.Text = "Nimike";
            this.nimikeToolStripMenuItem1.Click += new System.EventHandler(this.tsOA_Click);
            // 
            // btnMuokkaa
            // 
            this.btnMuokkaa.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMuokkaa.Location = new System.Drawing.Point(713, 511);
            this.btnMuokkaa.Name = "btnMuokkaa";
            this.btnMuokkaa.Size = new System.Drawing.Size(126, 51);
            this.btnMuokkaa.TabIndex = 4;
            this.btnMuokkaa.Text = "Muokkaa";
            this.btnMuokkaa.UseVisualStyleBackColor = true;
            this.btnMuokkaa.Click += new System.EventHandler(this.btnMuokkaa_Click);
            // 
            // btnPoista
            // 
            this.btnPoista.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPoista.Location = new System.Drawing.Point(914, 511);
            this.btnPoista.Name = "btnPoista";
            this.btnPoista.Size = new System.Drawing.Size(113, 51);
            this.btnPoista.TabIndex = 5;
            this.btnPoista.Text = "Poista";
            this.btnPoista.UseVisualStyleBackColor = true;
            this.btnPoista.Click += new System.EventHandler(this.btnPoista_Click);
            // 
            // frmHenkilotietoLomake
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ClientSize = new System.Drawing.Size(1335, 583);
            this.Controls.Add(this.btnPoista);
            this.Controls.Add(this.btnMuokkaa);
            this.Controls.Add(this.lbTiedot);
            this.Controls.Add(this.btnVieTiedot);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmHenkilotietoLomake";
            this.Text = "Henkilötieto Lomake";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox cbYksikko;
        private System.Windows.Forms.ComboBox cbNimike;
        private System.Windows.Forms.DateTimePicker dtpPaattyminen;
        private System.Windows.Forms.DateTimePicker dtpAlkaminen;
        private System.Windows.Forms.TextBox tbPostiPaikka;
        private System.Windows.Forms.TextBox tbPostiNro;
        private System.Windows.Forms.TextBox tbOsoite;
        private System.Windows.Forms.TextBox tbHetu;
        private System.Windows.Forms.TextBox tbKutsumanimi;
        private System.Windows.Forms.TextBox tbSukunimi;
        private System.Windows.Forms.TextBox tbEtunimet;
        private System.Windows.Forms.Button btnVieTiedot;
        private System.Windows.Forms.ListBox lbTiedot;
        private System.Windows.Forms.Label lblOsoiteTiedot;
        private System.Windows.Forms.Label lblHenkiloTiedot;
        private System.Windows.Forms.Label lblYksikkö;
        private System.Windows.Forms.Label lblNimike;
        private System.Windows.Forms.Label lblPaattyminen;
        private System.Windows.Forms.Label lblAlkaminen;
        private System.Windows.Forms.Label lblPostiPaikka;
        private System.Windows.Forms.Label lblPostiNro;
        private System.Windows.Forms.Label lblOsoite;
        private System.Windows.Forms.Label lblHetu;
        private System.Windows.Forms.Label lblKutsumanimi;
        private System.Windows.Forms.Label lblSukunimi;
        private System.Windows.Forms.Label lblEtunimet;
        private System.Windows.Forms.Label lblTyösuhdeTiedot;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem tiedostoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem järjestäToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tsAÖ;
        private System.Windows.Forms.ToolStripMenuItem tsÖA;
        private System.Windows.Forms.ToolStripMenuItem kutsumanimiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sukunimiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nimikeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kutsumanimiToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem sukunimiToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem nimikeToolStripMenuItem1;
        private System.Windows.Forms.Button btnMuokkaa;
        private System.Windows.Forms.Button btnPoista;
    }
}

